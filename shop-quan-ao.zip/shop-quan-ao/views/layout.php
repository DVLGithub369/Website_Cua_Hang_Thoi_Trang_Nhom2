<!DOCTYPE html>
<html lang="en">

<head>
    <title>Cửa Hàng Thời Trang</title>
    <base href="http://localhost/shop-quan-ao/">
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="./public/css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="./public/css/style.css">
    <link rel="stylesheet" type="text/css" href="./public/css/all.min.css">
    <script src="./public/js/jquery-3.5.1.min.js"></script>
</head>

<body>
    <div class="container px-0 py-0 mt-2">
        <header>
            <div class="info px-2">
                <a href="#" class="text-light">
                    <i class="fas fa-location"></i> 
                    Long Xuyên, AG
                </a>
                <a href="#" class="text-light">
                    <i class="fas fa-phone-alt"></i> 
                    Hotline: 1900 879 112
                </a>
                <div class="float-right">
                    <?php if(!isset($_SESSION['id'])){ ?>
                    <a href="index.php?q=dang-nhap" class="text-light">
                        <i class="fas fa-user"></i> 
                        Đăng nhập
                    </a>
                    <span class="text-light"> / </span>
                    <a href="index.php?q=dang-ky" class="text-light">
                        <i class="fas fa-user-plus"></i> 
                        Đăng ký
                    </a>
                    <?php }else{ ?>
                    <span class="text-light">Xin chào: <?php echo $_SESSION['tenDN'] ?></span>
                    <a href="index.php?q=dang-xuat" class="text-light">
                        <i class="fas fa-sign-out-alt"></i> 
                        Đăng xuất
                    </a>
                    <?php } ?>
                </div>
            </div>
            <img src="./public/images/3.jpg" class="img-top">
        </header>
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item active">
                        <a class="nav-link" href="#">
                            <i class="fas fa-home"></i>
                            Trang chủ
                        </a>
                    </li>
                    
                    <?php if(isset($_SESSION['id'])){ ?>
                        <li class="nav-item active">
                            <a class="nav-link" href="index.php?q=tai-khoan-cua-toi">
                                <i class="fas fa-user"></i>
                                Cá Nhân
                            </a>
                        </li>
                        <?php if($_SESSION['loaitk'] == 'admin'){ ?>
                        <li class="nav-item active">
                            <a class="nav-link" href="index.php?q=danh-sach-tai-khoan">
                                <i class="fas fa-users"></i>
                                Tài Khoản
                            </a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" href="index.php?q=danh-sach-loai-san-pham">
                                <i class="fas fa-tags"></i>
                                Loại Sản Phẩm
                            </a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" href="index.php?q=danh-sach-san-pham">
                                <i class="fab fa-product-hunt"></i>
                                Sản Phẩm
                            </a>
                        </li>
                        <li class="nav-item active">
                            <a class="nav-link" href="index.php?q=danh-sach-don-hang">
                                <i class="fas fa-cart-plus"></i>
                                Đơn Hàng
                            </a>
                        </li>
                        <?php }else{ ?>
                        <li class="nav-item active">
                            <a class="nav-link" href="index.php?q=don-hang-cua-toi">
                                <i class="fas fa-file-invoice-dollar"></i>
                                Đơn Hàng Của Tôi
                            </a>
                        </li>
                        <?php } ?>
                    <?php } ?>
                </ul>
                <form class="form-inline my-2 my-lg-0">
                    <input class="form-control mr-sm-2" type="search" name="search" placeholder="Tìm kiếm..." aria-label="Search" required>
                    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Tìm</button>
                </form>
            </div>
        </nav>

        <div id="content-main" class="container-fluid mt-1 py-1 px-0">
            <?php require_once "./views/trang_con/" . $data['trang'] . ".php"; ?>
        </div>

        <footer class="bg-dark text-center py-1 text-light">
            Copyright &copy; 2023
        </footer>
    </div>

    <script src="./public/js/popper.min.js"></script>
    <script src="./public/js/bootstrap.min.js"></script>
    <script src="./public/ckeditor/ckeditor.js"></script>
    <script type="text/javascript">
        $(document).ready(function(){
            CKEDITOR.replace('mota');
        });
    </script>
</body>

</html>