<div class="card mx-auto d-block">
	<div class="card-body">
		<form method="POST" action="index.php?q=xu-ly-sua-san-pham" enctype="multipart/form-data">
			<input type="text" name="id" value="<?php echo $data['sanpham']['id'] ?>" hidden>
			<input type="text" name="hinh_cu" value="<?php echo $data['sanpham']['hinh'] ?>" hidden>
			<div class="form-group">
				<label>TÊN SẢN PHẨM</label>
				<input type="text" class="form-control" name="ten" value="<?php echo $data['sanpham']['ten'] ?>" required>
			</div>
			<div class="form-group">
				<label for="exampleFormControlFile1">HÌNH ẢNH</label>
				<input type="file" class="form-control-file" id="exampleFormControlFile1" name="hinh">
			</div>
			<div class="form-group">
				<label>LOẠI SẢN PHẨM</label>
				<select class="form-control" name="loai" required>
					<option value="">-- chọn --</option>
					<?php foreach($data['loai'] as $value){ ?>
					<option value="<?php echo $value['ten'] ?>" <?php if($data['sanpham']['loai'] == $value['ten']) echo 'selected'; ?>><?php echo $value['ten'] ?></option>
					<?php } ?>
				</select>
			</div>
			<div class="form-group">
				<label>GIÁ BÁN</label>
				<input type="number" class="form-control" value="<?php echo $data['sanpham']['gia'] ?>" name="gia" required>
			</div>
			<div class="form-group">
				<label>MÔ TẢ</label>
				<textarea class="form-control" id="mota" name="mota"><?php echo $data['sanpham']['mota'] ?></textarea>
			</div>
			<div class="text-center">
				<button type="submit" class="btn btn-primary">Lưu dữ liệu</button>
			</div>
		</form>
	</div>
</div>