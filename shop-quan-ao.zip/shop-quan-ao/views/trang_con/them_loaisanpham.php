<div class="card mx-auto d-block" style="width: 450px;">
	<div class="card-body">
		<form method="POST" action="index.php?q=xu-ly-them-loai-san-pham">
			<div class="form-group">
				<label>TÊN LOẠI</label>
				<input type="text" class="form-control" name="ten" required>
			</div>
			<div class="text-center">
				<button type="submit" class="btn btn-primary">Lưu dữ liệu</button>
			</div>
		</form>
	</div>
</div>